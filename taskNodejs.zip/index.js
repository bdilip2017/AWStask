'use strict'
const S3 = require('aws-sdk/clients/s3')
const s3 = new S3()

const bucketName = 'awstaskterraformdilip'
const fileKey = 'key'
const inputParam = 'elb_dns_name'
exports.handler = async function(event){
let data = await getStateFileData()
let respectiveOutput = await getResOutput(data,inputParam)
return data;

}

const getStateFileData = async () => {
    const data = await s3.getObject({
        Bucket: bucketName,
        Key: fileKey
    }).promise()
const stateData = JSON.parse(data.Body)
const outputs = stateData.outputs

return outputs
}

async function getResOutput(data, inputParam) {
let output = data[inputParam];
return output
}